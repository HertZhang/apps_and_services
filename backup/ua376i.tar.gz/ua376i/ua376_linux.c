//#include "windows.h"
//#include "setupapi.h"	// VC++ 5 one is out of date
#include "stdio.h"
//#include "initguid.h"
//#include "GUIDs.h"
//#include "winioctl.h"
//#include "Ioctl.h"
#include "ftd2xx.h"

//HANDLE GetDeviceViaInterface( GUID* pGuid, DWORD instance);
void outadb(UCHAR b,UCHAR d);
UCHAR inadb(UCHAR);

FT_HANDLE ftHandle;
FT_STATUS ftStatus;
unsigned char ClsBuf[65536];


DWORD BytesReturned;
long ss1;
short dam0=1,dam1=1;

int  outb(FT_HANDLE ftHandle, UCHAR port ,UCHAR dat1)
{

	DWORD BytesWritten;
    UCHAR TxBuffer[2];
	TxBuffer[0]=port;
	TxBuffer[1]=dat1;

	return FT_Write(ftHandle,TxBuffer,2,&BytesWritten);

}

int  OpenUA376(int n, FT_HANDLE ftHandle)
//int OpenUA376(int n,FT_HANDLE *ftHandle)
{

ftStatus = FT_Open(n,&ftHandle);
//ftStatus=FT_Open(n,ftHandle);

if(ftStatus==0){
  FT_Purge(ftHandle, FT_PURGE_RX | FT_PURGE_TX);

	outb(ftHandle,255,255);
	outb(ftHandle,255,255);
//	outb(ftHandle,11,0);

  FT_Purge(ftHandle, FT_PURGE_RX | FT_PURGE_TX);

	outb(ftHandle,0x14,0);
	outb(ftHandle,0x10,0);
	outb(ftHandle,0x11,0);
	outb(ftHandle,0x12,0);
	outb(ftHandle,0x13,0);
}
//if (ftStatus == FT_OK) {
// FT_Open OK, use ftHandle to access device } else { // FT_Open failed }
return ftStatus;
}


int  CloseUA376(FT_HANDLE ftHandle)
{
return FT_Close(ftHandle);
}



void  dout(FT_HANDLE ftHandle,BYTE dd)
{
	outb(ftHandle,15,0);
	outb(ftHandle,14,dd);
}

int  ss376(FT_HANDLE ftHandle,short *addat,short fch,short chn,short gn)
{

FT_STATUS status;
DWORD BytesReceived; 
//unsigned char RxBuffer[256];
//DWORD EventDWord; DWORD TxBytes; DWORD RxBytes;

	DWORD BytesWritten;
    UCHAR TxBuffer[64];

	outb(ftHandle,255,255);

	outb(ftHandle,12,0);
	outb(ftHandle,0x16,0);
	outb(ftHandle,11,0);

    status = FT_Purge(ftHandle, FT_PURGE_RX | FT_PURGE_TX);


	TxBuffer[0]=255;
	TxBuffer[1]=255;

	TxBuffer[2]=8;     
	TxBuffer[3]=24;
	TxBuffer[4]=9;
	TxBuffer[5]=252;   // 10KHz

	if(gn==0)gn=1;
	TxBuffer[6]=0x14;
	TxBuffer[7]=(UCHAR)(gn-1);  //set gain
	
	TxBuffer[8]=0x15;
	TxBuffer[9]=65;            //set 273-mode

	TxBuffer[10]=13;
	TxBuffer[11]=(UCHAR)fch;
	TxBuffer[12]=0x17;
	TxBuffer[13]=(UCHAR)chn;

	TxBuffer[14]=0x16;
	TxBuffer[15]=0;            //fs

	TxBuffer[16]=10;
	TxBuffer[17]=0;            //LDCK
	TxBuffer[18]=11;
	TxBuffer[19]=255;          //clk on

	TxBuffer[20]=12;
	TxBuffer[21]=255;          //clk on


	FT_Write(ftHandle,TxBuffer,22,&BytesWritten);

	
 	status=FT_Read(ftHandle,(PCHAR)addat,chn*2,&BytesReceived);
 	status=FT_Read(ftHandle,(PCHAR)addat,chn*2,&BytesReceived);

	TxBuffer[0]=11;
	TxBuffer[1]=0;
	TxBuffer[2]=12;
	TxBuffer[3]=0;

	FT_Write(ftHandle,TxBuffer,4,&BytesWritten);
   

    status = FT_Purge(ftHandle, FT_PURGE_RX | FT_PURGE_TX);

	return status;

}

int  mm376(FT_HANDLE ftHandle,short *addat,short fch,short chn,long fr,long leg,short gn)
{

	FT_STATUS status;
	DWORD BytesReceived; 
	DWORD EventDWord; DWORD TxBytes; DWORD RxBytes;
	long fn;
	BYTE fnh,fnl;

	DWORD BytesWritten;
    UCHAR TxBuffer[64];

	fn=10000000/(fr*1);
	fn=65536-fn;
	fnh=fn/256;
	fnl=fn%256;

    status = FT_Purge(ftHandle, FT_PURGE_RX | FT_PURGE_TX);

	outb(ftHandle,255,255);
	outb(ftHandle,0x16,0);

	outb(ftHandle,12,0);
	outb(ftHandle,11,0);

	FT_GetStatus(ftHandle,&RxBytes,&TxBytes,&EventDWord);
	if(RxBytes>0){
		status=FT_Read(ftHandle,ClsBuf,RxBytes,&BytesReceived);
	}


	TxBuffer[0]=255;
	TxBuffer[1]=255;

	TxBuffer[2]=8;     
	TxBuffer[3]=fnl;
	TxBuffer[4]=9;
	TxBuffer[5]=fnh;   // 10KHz

	if(gn==0)gn=1;
	TxBuffer[6]=0x14;
	TxBuffer[7]=(UCHAR)(gn-1);  //set gain
	
	TxBuffer[8]=0x15;
	TxBuffer[9]=64;            //set 273-mode

	TxBuffer[10]=13;
	TxBuffer[11]=(UCHAR)fch;
	TxBuffer[12]=0x17;
	TxBuffer[13]=(UCHAR)chn;

	TxBuffer[14]=0x16;
	TxBuffer[15]=0;            //fs

	TxBuffer[16]=10;
	TxBuffer[17]=0;            //LDCK
	TxBuffer[18]=11;
	TxBuffer[19]=255;          //clk on
	TxBuffer[20]=12;
	TxBuffer[21]=255;          //clk on


	FT_Write(ftHandle,TxBuffer,22,&BytesWritten);

    status=FT_Read(ftHandle,(PCHAR)addat,chn*2,&BytesReceived);
    status=FT_Read(ftHandle,(PCHAR)addat,leg*2,&BytesReceived);

	TxBuffer[0]=11;
	TxBuffer[1]=0;
	TxBuffer[4]=12;
	TxBuffer[5]=0;

	FT_Write(ftHandle,TxBuffer,4,&BytesWritten);
	
	status = FT_Purge(ftHandle, FT_PURGE_RX | FT_PURGE_TX);

	return status;

}


int  get_status(FT_HANDLE ftHandle,DWORD *RxBytes,DWORD *TxBytes)
{
FT_STATUS status;
DWORD EventDWord;

	status=FT_GetStatus(ftHandle,*(&RxBytes),*(&TxBytes),&EventDWord);
	return status;
}

int  stop376(FT_HANDLE ftHandle)
{
FT_STATUS status;

	outb(ftHandle,255,255);
	outb(ftHandle,11,0);
	outb(ftHandle,12,0);

	status = FT_Purge(ftHandle, FT_PURGE_RX | FT_PURGE_TX);

	return status;
}

int  read376(FT_HANDLE ftHandle,short *addat,long leg)
{
	FT_STATUS status;
	DWORD BytesReceived;
 
	status=FT_Read(ftHandle,(PCHAR)addat,leg*2,&BytesReceived);

	return status;
}

int  start376(FT_HANDLE ftHandle,short fch,short chn,long fr,short gn)
{

	FT_STATUS status;
	DWORD BytesReceived; 

	long fn;
	BYTE fnh,fnl;

	DWORD BytesWritten;
    UCHAR TxBuffer[64];

	fn=10000000/(fr*1);
	fn=65536-fn;
	fnh=fn/256;
	fnl=fn%256;

	outb(ftHandle,255,255);
	outb(ftHandle,12,0);
	outb(ftHandle,11,0);
	outb(ftHandle,0x16,0);

	status = FT_Purge(ftHandle, FT_PURGE_RX | FT_PURGE_TX);


	TxBuffer[0]=255;
	TxBuffer[1]=255;

	TxBuffer[2]=8;     
	TxBuffer[3]=fnl;
	TxBuffer[4]=9;
	TxBuffer[5]=fnh;   // set fr

	if(gn==0)gn=1;
	TxBuffer[6]=0x14;
	TxBuffer[7]=(UCHAR)(gn-1);  //set gain
	
	TxBuffer[8]=0x15;
	TxBuffer[9]=64;            //set 273-mode

	TxBuffer[10]=13;
	TxBuffer[11]=(UCHAR)fch;
	TxBuffer[12]=0x17;
	TxBuffer[13]=(UCHAR)chn;

	TxBuffer[14]=0x16;
	TxBuffer[15]=0;            //fs

	TxBuffer[16]=10;
	TxBuffer[17]=0;            //LDCK
	TxBuffer[18]=11;
	TxBuffer[19]=255;            //LDCK
	TxBuffer[20]=12;
	TxBuffer[21]=255;          //clk on

	FT_Write(ftHandle,TxBuffer,22,&BytesWritten);


	status=FT_Read(ftHandle,ClsBuf,chn*2,&BytesReceived);

	return status;
}











