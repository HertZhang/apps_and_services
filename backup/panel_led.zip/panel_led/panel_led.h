#ifndef PANEL_LED_H
#define PANEL_LED_H

#include <stdio.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

